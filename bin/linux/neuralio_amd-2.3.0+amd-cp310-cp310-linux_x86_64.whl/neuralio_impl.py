import torch
import time
import os

# CRITICAL: Capture original torch.save BEFORE any monkey patching happens
# This prevents infinite recursion when falling back in save()
_ORIGINAL_TORCH_SAVE = torch.save

try:
    import neuralio_final as core
    print("[NeuralIO] Extension Methods:", dir(core.NeuralIOEngine))
except ImportError:
    core = None

class NeuralIOStorage:
    def __init__(self, chunk_size, vram_budget):
        if core:
            # FIX: C++ Engine only accepts a config file path.
            # We must write our runtime defaults to a temp config to ensure C++ sees them.
            import json
            import tempfile
            
            session_config = {
                "calibrated": True, # Force C++ to trust these values
                "chunk_size": int(chunk_size),
                "vram_budget_mb": int(vram_budget / (1024**2)),
                "io_strategy": "BUFFERED",  # Safe default
                "io_threads": 4,
                "compression": True
            }
            
            # Write to a unique temp file to avoid conflicts
            fd, temp_path = tempfile.mkstemp(suffix=".json", prefix="nio_session_")
            with os.fdopen(fd, 'w') as f:
                json.dump(session_config, f)
                
            self.temp_config_path = temp_path
            print(f"[NeuralIO] Session Config Generated: {session_config}")
            
            self.engine = core.NeuralIOEngine(self.temp_config_path)
            
            # Clean up temp file (Best effort, C++ loads it immediately)
            # os.remove(temp_path) # Wait, verify if C++ keeps it open? C++ reads and closes.
        else:
            print("[NeuralIO] Warning: Accelerated engine not available.")
            self.engine = None
        self.last_save_metrics = {}

    def save(self, tensor, filename, rank=-1):
        if self.engine is None:
             # Now that environment is fixed, we can be strict again, or keep warning.
             # User wants persistence, let's keep it safe but fully GPU enabled if possible.
             print("[NeuralIO] Warning: Extension missing, using torch.save (CUDA).")
             final_name = filename
             if rank >= 0:
                 final_name = f"{filename}_rank_{rank}"
             
             start_t = time.time()
             _ORIGINAL_TORCH_SAVE(tensor, final_name)
             dt = time.time() - start_t
             
             # Populate metrics for 'safe.py' to consume
             ptr = tensor.data_ptr()
             size = tensor.numel() * tensor.element_size()
             self.last_save_metrics = {
                "saved_mb": size / 1024**2,
                "compute_time_ms": dt * 1000.0,
                "io_time_ms": dt * 1000.0,
                "effective_speed_gbs": (size / 1e9) / dt if dt > 0 else 0
             }
             return
             
        if not tensor.is_cuda:
            raise ValueError("NeuralIO requires CUDA tensors for acceleration.")
        
        # Pass the memory address directly to C++
        ptr = tensor.data_ptr()
        size = tensor.numel() * tensor.element_size()
        
        start_time = torch.cuda.Event(enable_timing=True)
        end_time = torch.cuda.Event(enable_timing=True)
        
        start_time.record()
        self.engine.save_tensor_sharded(ptr, size, filename, rank)
        aligned_footer_offset = (size + 4095) // 4096 * 4096
        self.engine.write_footer(filename, 1, aligned_footer_offset)
        end_time.record()
        
        torch.cuda.synchronize()
        
        # Performance Tracking
        elapsed = start_time.elapsed_time(end_time) # ms
        
        # FIX: Wait for I/O threads to finish updating metrics
        if hasattr(self.engine, 'sync'):
            self.engine.sync()
            
        # Performance Tracking
        # Fetch metrics directly from C++ engine (exposed as property)
        self.last_save_metrics = self.engine.last_save_metrics

    def load(self, filename, tensor):
        """Loads data from filename into tensor (in-place)."""
        if self.engine:
            # Check if file exists
            if not os.path.exists(filename):
                raise FileNotFoundError(f"File not found: {filename}")
                
            # Use C++ Fast Load
            if not tensor.is_cuda:
                 raise ValueError("NeuralIO loads into CUDA tensors only.")
            
            ptr = tensor.data_ptr()
            size = tensor.numel() * tensor.element_size()
            
            # Check if C++ load is available
            if hasattr(self.engine, 'load_tensor'):
                self.engine.load_tensor(ptr, size, filename)
            else:
                # C++ Method missing (Binary Access Fallback)
                # Read raw bytes directly from file start
                # Valid because we know the file structure: [RAW DATA] ... [FOOTER]
                try:
                    with open(filename, 'rb') as f:
                        # Create a CPU buffer to read into
                        # Use zeros() so if read is short, the rest is 0 (safe padding)
                        cpu_tensor = torch.zeros(tensor.shape, dtype=tensor.dtype, device='cpu')
                        
                        # Use memoryview to read directly into the tensor's buffer
                        if cpu_tensor.is_contiguous():
                             bytes_read = f.readinto(memoryview(cpu_tensor.numpy()))
                             if bytes_read != size:
                                 diff = size - bytes_read
                                 if diff > 0 and diff < 65536: # Tolerate missing footer/alignment
                                     print(f"[NeuralIO] Info: File short by {diff} bytes (Metadata/Footer missing). Padding with zeros.")
                                 elif diff != 0:
                                     raise IOError(f"File too short. Expected {size} bytes, got {bytes_read}")
                        else:
                             # Fallback for non-contiguous
                             data = f.read(size)
                             if len(data) < size:
                                  # Pad
                                  data = data + b'\0' * (size - len(data))
                             cpu_tensor.set_(torch.frombuffer(data, dtype=tensor.dtype).reshape(tensor.shape))
                        
                        tensor.copy_(cpu_tensor)
                except Exception as e:
                    print(f"[NeuralIO] Binary load failed: {e}")
                    raise e
        else:
            # Fallback Load (Pickle)
            # Problem: torch.load returns a new tensor, doesn't load in-place usually.
            # But we can copy.
            print("[NeuralIO] Warning: Loading with torch.load (Slow)")
            data = torch.load(filename, map_location=tensor.device)
            if isinstance(data, torch.Tensor):
                tensor.copy_(data)
            else:
                # If user saved a dict but trying to load into tensor?
                raise RuntimeError("Saved object was not a tensor, cannot load into tensor.")
